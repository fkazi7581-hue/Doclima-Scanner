package com.example.doclima_scanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
